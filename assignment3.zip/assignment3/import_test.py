def cat_n_times(s, n):
	input_string=""
	
	for i in range(0,int(n),1):
		input_string=input_string+s

	print input_string
