def assignmnet7():
	print "enter a noun"
	noun= raw_input()
	
	print "enter a verb"
	verb= raw_input()

	print "enter an adjective"
	adjective= raw_input()

	print "enter an adverb"
	adverb= raw_input()

	print "enter a plural  noun"
	pnoun= raw_input()

	print "enter a past tense verbs"
	ptverb= raw_input()

	print  verb + " " + noun +" "+ adverb+ " "+ pnoun +" "+ptverb +" "+adjective

assignmnet7()

