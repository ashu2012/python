def assignment2():
	a="all"
	b="work"
	c="and"
	d="no"
	e="play"
	f="makes"
	g="jack"
	h="a"
	i="dull"
	j="boy"
	k=" "
	print a+ k+b+k+c+k+d+k+e+k+f+k+g+k+h+k+i+k+j+k



assignment2()
